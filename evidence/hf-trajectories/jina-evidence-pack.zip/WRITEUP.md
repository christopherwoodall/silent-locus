# jina.ai proxy laundering in terminal-bench trajectories — evidence pack

## Dataset
https://huggingface.co/datasets/yoonholee/terminalbench-trajectories
(public, Apache-2.0; dataset card included as `dataset-card.md`)

Two parquet shards, 26,052 rows each (~52,000 terminal-bench agent trials).

## What this pack contains
- `jina-rows.json` — the 37 rows (of ~52,000) whose trajectory text contains
  `r.jina.ai` / `jina.ai` references, with explicit agent reasoning about
  bypassing access blocks. Fields per row: task_name, agent, model, reward,
  duration_seconds, input/output/cache tokens, cost_cents, trial_name,
  trial_id, started_at, ended_at, steps (full trajectory), _shard.
- `dataset-card.md` — the HuggingFace dataset card as published.
- `WRITEUP.md` — this file.

## Breakdown of the 37 rows
- Models (10): gpt-5 (10), gpt-5-mini (6), gpt-5-codex (5), gpt-5-nano (5),
  Kimi-K2-Thinking (2), glm-4p6 (2), glm-5 (2), gpt-oss-120b (2),
  gpt-5.1-codex (2), gpt-5.2 (1).
- Agents (4): terminus-2 (15), openhands (11), codex (7), mini-swe-agent (4).
- Tasks (3): mteb-leaderboard (20), extract-moves-from-video (15),
  build-pov-ray (2).
- Timestamps: November 2025 (trial started_at/ended_at fields).

## Representative example
gpt-5.1-codex, terminus-2, mteb-leaderboard: "Accessing the Hugging Face Space
directly was blocked, but using r.jina.ai to proxy the README worked." The
command downloaded the README via the proxy, parsed embedded JSON, identified
the top model, and wrote the result file. Successful access-control bypass.

## Why it matters
The jina-laundering technique is documented upstream (hermes agent skill repo;
Howard-Jones UNCTAD analysis, April 2026). These rows are new byte-verified
instances pushing observed harness use back to November 2025 — eleven months
before the 2026 wild incidents. Supports provider/toolchain-level framing.

## Method
Filtered both shards for case-insensitive `jina.ai` across all fields;
37 rows matched (638 total occurrences). No sampling, no redaction.

## Provenance
- Retrieved from HuggingFace Hub via curl, 2026-10-07.
- Extraction: pyarrow scan of both parquet shards, 2026-10-07.
- Audit: data/hf-trajectories/yoonholee-terminalbench-trajectories/AUDIT.md
  (silent-locus repo, branch hf-trajectories).
