# verification-collapse-evidence.zip — README

Evidence pack for the writeup WRITEUP-verification-collapse.md.
All trajectory files are the exact raw bytes from
https://huggingface.co/datasets/CLoud5-real/longrca-bench
pinned revision 9f45acb66948d5d20c663b4ce4ec8ea5ab0076dd.
Nothing is redacted. Re-fetch any file by revision + path + sha256.

| Finding | File | sha256 | Steps cited |
|---|---|---|---|
| F-A01 | terminal_bench_2__016.json | c4e4dd414128fd1e94dbca16943d4c70d300db6a8ca9627b5fd2eb6b909ceee1 | see writeup |
| LB-F001 | travelplanner__595.json | 5b4e5149b592e007d46b0cf7a0331658c4aa32084c7a8066dd7d18e3f11b0abc | see writeup |
| LB-F002 | travelplanner__592.json | bb9e50c5817fcc49d4c363cbabcc970706e94d184bd0ae5b9bd22cf3b5e8c909 | see writeup |
| F-A04 | travelplanner__137.json | ea79d7db4e2d103947aa516b4e21026147ba41c87d6014d59a06149a78fb5851 | see writeup |
| F-A05 | travelplanner__392.json | be85979129bd70ea06601ab3117d54b1c95ca514af62e77a313b8e285e028021 | see writeup |
| LB-F006 | travelplanner__473.json | b9d4b1d2ede06b6fa8aabe2546a1e657207442b6275af133b3ee6c0941327c17 | see writeup |
| LB-F008 | travelplanner__635.json | 0a31541e86524293c46be71d80fee67df55621d71a6108051684f6541b97588d | see writeup |
| LB-F005 | travelplanner__588.json | 34921de561307c108f0bd1a5dcd5cdebca22dc7799d7341071737393606078ab | see writeup |
| LB-F003 | travelplanner__503.json | a02f7b468570b27d49b347a5ccbfb2c5e486436948f9792000ea5acc3d46de98 | see writeup |
| LB-F009 | travelplanner__594.json | 10995ae444116034b69e18583e68ef1657bdcebd1179ce735abdcfa7bd93c626 | see writeup |
| LB-F011 | travelplanner__430.json | 2c9b3c2f920294eecbfa0baa86de08241db3579ca54fc09ef0fd99fd34140f15 | see writeup |

WRITEUP-verification-collapse.md is the draft writeup (ON HOLD,
not submitted — Transluce filing freeze in force).
url-harvest.json lists the 179 URLs touched by agents in these
trajectories (also appended to lists/urls/urls.jsonl).

- 2608.15242.pdf — LongRCA Bench paper (arXiv:2608.15242), sha256 674413ee46359c98...
